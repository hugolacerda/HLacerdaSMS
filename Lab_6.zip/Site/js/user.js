var microphoneList = $('.microphoneList');
var cameraList = $('.cameraList');


var playing = false;

var record = $(".record");

var durationSlider = 0;

var timeSlider = 0;

var recording = false;



var connected = function(success,error){
	
	console.log(success, "connected");
	flash.startPlaying("hobbit_vp6.flv");
	playing = true;

}

var getDuration = function(duration){

	console.log("this is the duration: " ,duration);
	
	durationSlider = duration;


};

var seekTime = function(time){

	// console.log("this is the time: " ,time);

	timeSlider = time;

	var sliderX = $(".slider").position().left;

	// console.log("timeSlider: " ,timeSlider, "durationSlider: ", durationSlider );

	var x = (timeSlider / durationSlider) * 958;

	// console.log("slider x: ", sliderX, "x normal: ", x);

	sliderX += x;

	$(".slider").css("left", x);

};


var flashReady = function(){
		
	flash.connect("rtmp://localhost/SMSServer2");

	$(".play").click(function(){
				
				console.log("plays has been clicked");
				
				flash.playPause();
	});

	$('#microphone').click(function(){
		microphoneList.css('display','block');
		cameraList.css('display','none');

		var microphones = flash.getMicrophones();
		console.log(microphones);
		microphoneList.html('<li>'+microphones+'</li>');
	});

	$('#camera').click(function(){
		cameraList.css('display','block');
		microphoneList.css('display','none');

		var cameras = flash.getCameras();
		console.log(cameras);
		cameraList.html('<li>'+cameras+'</li>');
	});


	// record.click(function(){

	// 	console.log("RECORDING!!!");

	// 	if(!recording){
	// 		flash.startRecording("movie", 0.0);
	// 	}else{
	// 		flash.stopRecording();
	// 		recording = false;
	// 	}

	// });



};

record.click(function(){
	console.log("RECORDING!!!");
	if (!recording) {
		flash.startRecording('movie', 0, 0);
		recording = true;
	} else {
		flash.stopRecording();
		recording = false;
	}
});


	